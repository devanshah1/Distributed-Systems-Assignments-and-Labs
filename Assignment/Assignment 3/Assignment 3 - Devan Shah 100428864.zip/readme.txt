Running Code for Question 1
	Question 1 No Synchronization
		0. Unzip the zip file
		1. Open command line
		2. Change directory into Distributed Systems - Assignment 3 - Question 1 No Synchronization\src build the java code using command javac *
		3. Run program with command "java CountingThreadInit"
	Question 1 With Synchronization
		0. Unzip the zip file
		1. Open command line
		2. change directory into Distributed Systems - Assignment 3 - Question 1 With Synchronization\src build the java code using command javac *
		3. Run program with command "java CountingThreadInit"
